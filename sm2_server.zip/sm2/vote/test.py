m="123|ok"

print(m.split("|")[1])